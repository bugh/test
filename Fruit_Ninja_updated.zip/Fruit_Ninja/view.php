<html>

<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Fruit Ninja | CTF </title>
    <meta name="Nova theme" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/png" href="#"/>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
          integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"
          rel="stylesheet">
    <link rel="stylesheet" href="assets/css/style.css"/>
    <link rel="stylesheet" href="assets/css/responsive.css"/>

    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css"/>

</head>

<body>

<!-- White-Section
  ================================================== -->

<div class="white-section row">

    <div class="imac col-sm-6">

<?php
	
	$pic = $_REQUEST['id'];
	if($pic == "" || $pic == "random")
		{
			$picname = "./assets/pre/" . rand(1,14) . ".jpg";
		}
	else $picname = "./imgs/" . $pic . ".jpg";
		{
			echo '<img class="imac-screen img-responsive" src="' . $picname . '">';
		}
?>

    </div>
    <!--imac-->

    <div class="col-sm-6">

        <div class="white-section-text">

            <h2 class="imac-section-header light"></h2>

            <div class="imac-section-desc">

            <span> I Love this Fruit...:)</span>
            </div>
        </div>
    </div>
</div><!--white-section-text-section--->
<br>
<br><br>
<br><br><br>
<br><br><br><br>
<br><br><br><br><br>
<br><br><br><br><br><br>
<br><br><br><br><br><br><br>



<!-- Footer
  ================================================== -->

<div class="footer">

    <div class="container">
        <div class="row">

            <div class="col-sm-2"></div>

            <div class="col-sm-8 webscope">
                <span class="webscope-text"> Copyright @ 2020 Init Crew</span>
            <!--webscope-->
        </div>
        <!--row-->

    </div>
    <!--container-->
</div>
</body>

</html>
