<!DOCTYPE HTML>
<html>
    <body>
    <header>
<style>
html,body{
    background-color: black;
    color:orangered;
    scroll-behavior: smooth;
    height: 100%;
}
.nav-bar{
    border-bottom-color:transparent;
    justify-content: space-between;
    display: grid;
    grid-auto-flow: column;
    width: 95%;
    position: fixed;
}
.logo{
    padding: 5px 5px 5px 10px;
    justify-content:start;
}
#logo-img{
    width:60px;
    height: 60px;
    justify-content: start;
}
.tab,a{
    display: grid;
    grid-gap: 8px;
    grid-auto-flow: column;
    padding-right: 10px;
    text-decoration: none;
    color: orangered;
    position: relative;
}
.tab a:hover{
    color:darkred;
}
#main{
    font-size: 62px;
    text-align: center;
    font-family: 'Courier New', Courier, monospace;
    background-color: black;
    color: orangered;
    margin:50px 0px 250px 0px;
    padding: 150px 0px 30px 0px;
    animation: change .75s infinite;
}
@keyframes change {
    from{color: orangered;}
    to {color: darkred;}
}
#parallax{
   background-attachment: fixed;
   background-position: center;
   background-repeat: no-repeat;
   background-size: auto;
   height: 100%;
   width: 100%;
   bottom: 50px;
   margin-bottom: 70px;
}
.about{
    align-items: center;
    justify-content: center;
    height: 20vh;
    padding: 50px 0px 50px 0px;
    background-image: url(images/13.jpg);
}
.about h1{
    text-align: center;
    font-size: 60px;
}
.exp{
    text-align: justify;
    padding: 30px 0px 30px 0px;
}
.contact-forms{
    display:grid;
    grid-auto-flow: column;
    outline: none;
    border-color: transparent;
    margin-top: 12px;
}
.name{
    font-size: 60px;
    text-align: center;
    padding-top: 50px;
    display: grid;
    grid-auto-flow: column;
    grid-gap: 4px;
}
.form{
    align-items: center;
    justify-content: center;
    padding: 1px 0px 30px 45px;
    margin-top: 100px;
    color: orangered;
    background-color: black;
    width: 550px;
    height: 150px;
    display: grid;
}
fieldset{
    justify-content: center;
    align-items: center;
    padding: 30px 10px 30px 10px;
    margin: auto;
    border-color: orangered;
    border-radius: 10px;
}
input,textarea{
    border-color: transparent;
    background-color: black;
    color: orangered;
    border-bottom-color: orangered;
    text-decoration: none;
}
legend{
    font-size: 22px;
}
#field{
    width: 90%;
}
button{
    background-color: black;
    border-radius: 10px;
    padding: 16px 32px;
    text-decoration: none;
    margin: 8px 2px;
    cursor: pointer;
    color:orangered;
    font-family: Bangers;
    font-size: 22px;
    border-color: orangered;
    margin-top: 25px;
}
button:hover{
    background-color: orangered;
    color:black;
    border-color: black;
}
footer{
    position: absolute;
    color: orangered;
    text-align: center;
    width: 100%;
    margin-top: 250px;
}
</style>
    <title>Love_Letter</title>
        <link rel="icon" 
      type="image/png"
      href='images/icon1.png'/>
        <nav class = 'nav-bar'>
            <div class = 'nav-sec logo'>
                <a href = '#'><img src = 'images/icon1.png' id = 'logo-img'></a>
            </div>
            <div class = 'nav-sec tab'>
                <a href="#"><h3>Home</h3></a>
              <a href="#about"><h3>About Us</h3></a>
                <a href="#contact"><h3>Contact Us</h3></a>
            </div>
        </nav>
    </header>
    <content>
    <div id = 'main'>
            <h1>Love_Letter</h1>
        </div >
    <div class = 'about' id = 'about'>
            <h1>Who We Are</h1>
        </div>
    <div class = 'exp'>
            <p>
                Pariatur enim eiusmod cupidatat elit. Incididunt sint minim adipisicing et. Laborum irure adipisicing laborum sint non voluptate proident adipisicing qui laboris est ex tempor.Mollit voluptate nisi mollit quis voluptate veniam commodo ad adipisicing sint ipsum. Exercitation exercitation nulla nostrud mollit. Ex ipsum ut commodo anim nulla aliqua pariatur aliquip mollit ut adipisicing sunt. Ullamco sunt incididunt fugiat incididunt eu mollit qui enim ut consectetur adipisicing esse amet laborum. Veniam exercitation incididunt laboris id quis aliqua. Aliqua dolore dolor cillum eiusmod duis ad proident excepteur ipsum. Magna exercitation exercitation Lorem ex duis Lorem id anim voluptate et.Officia sint commodo esse tempor voluptate amet nulla enim ipsum nisi labore laboris excepteur. Laborum voluptate nulla tempor reprehenderit. Occaecat ad adipisicing sunt dolore duis nostrud incididunt occaecat sint ad magna quis reprehenderit.Sit est culpa ea et ipsum eiusmod esse est voluptate. Commodo voluptate minim esse aliquip irure esse sunt cillum et duis fugiat id voluptate do. Minim non eu consequat nisi labore magna irure quis tempor pariatur enim laboris elit. Duis aute ad ipsum et in minim enim consectetur fugiat eiusmod sit eu proident elit. Labore adipisicing aliqua cupidatat pariatur elit ullamco. Irure incididunt elit ex nisi magna esse magna dolor ex excepteur ut veniam do officia. Non culpa non cillum ad commodo ea adipisicing enim irure est labore.Laboris proident laborum et voluptate exercitation. Deserunt proident irure Lorem minim do duis proident est dolor et id nulla. Labore fugiat est sit deserunt culpa ullamco aliquip sit.Ullamco mollit reprehenderit ea ea ipsum nostrud ipsum anim. Proident proident enim esse deserunt reprehenderit laborum. Exercitation anim tempor ut sit excepteur excepteur occaecat in nulla. Nulla elit irure occaecat do commodo. Sit id et duis ea. Voluptate aliquip ex ullamco reprehenderit duis ea in occaecat dolore aute.Laboris laborum culpa laboris ea esse ex consectetur tempor officia. Nostrud proident occaecat occaecat et consectetur sit. Minim quis ullamco qui aliquip non sit irure Lorem et voluptate incididunt reprehenderit. Sint pariatur nulla consequat anim officia et proident minim proident incididunt aute. Deserunt ea id ad cillum irure exercitation reprehenderit consequat aute sint laborum.Occaecat ullamco sunt sint cupidatat et pariatur magna consectetur veniam qui. Aliqua ullamco magna dolore ea ullamco ipsum. Id elit nisi ad minim non deserunt. Est est proident non ad mollit laborum Lorem pariatur dolore sint sint. Magna est mollit consequat id adipisicing in consectetur minim incididunt deserunt irure. Et ipsum cillum duis et excepteur aute voluptate ex.

            </p>
        </div>
    <div>
            <img id = 'parallax' src="images/13b.jpg" alt="">
        </div>
    <div class= 'contact-forms'>
        <div class = 'contact-forms name' id ='contact'>
            <h1>Contact Us</h1>
        </div>
<div  class = "contact-form form">
        <form name= 'thisform' action = "index.php" method = "post" enctype = "multipart/form-data">
        <input type="hidden" name="action" value="submit">
        <fieldset id = "field">
                <legend>
                    Contact Form
                </legend>
                <h3>Name</h3><br>
                <input id = 'field' type="text" placeholder="Enter Name" required><br>
                <h3>Email Id</h3><br>
                <input id = "field" type="email" placeholder="Enter Mail" required><br>
                <h3>Message</h3>
                <textarea id = 'field' required placeholder="Type your Message here......"  maxlength="150"></textarea>
                <button type = 'submit' form = 'thisform' value = 'Submit'>Submit</button>
            </fieldset>
<?php
if (isset($_REQUEST['action'])){
    $name=$_REQUEST['name'];
    $email=$_REQUEST['email'];
    $message=$_REQUEST['message'];
    if (($name=="")||($email=="")||($message=="")){
        echo "There are missing fields.";
    }else{		

        require 'vulnerable/PHPMailerAutoload.php';
        $mail = new PHPMailer;
        $mail->Host = "localhost";

        $mail->setFrom($email, 'Vulnerable Server');
        $mail->addAddress('admin@vulnerable.com', 'Hacker');
        $mail->Subject  = "Message from $name";
        $mail->Body     = $message;
        if(!$mail->send()) {
            echo 'Message was not sent.';
            echo 'Mailer error: ' . $mail->ErrorInfo;
        } else {
            echo 'Message has been sent.';
        }

    }
}  
?>
        </form>
        </div>
        </div>
</content>
<footer>
        <p>Copyright &copy; 2016 Love_Letter. All Rights Reserved</p>
        </footer>
        </body>
     </html>
