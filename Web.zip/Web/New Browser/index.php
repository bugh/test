<?php
$flag = 'FL4G{d0_y0u_l1k3_7h3_br0w53r}';
function getIP()
{
	if (@$_SERVER["HTTP_X_FORWARDED_FOR"]){
		$ip = $_SERVER["HTTP_X_FORWARDED_FOR"];
	}else if (@$_SERVER["HTTP_CLIENT_IP"]){
		$ip = $_SERVER["HTTP_CLIENT_IP"];
	}else if (@$_SERVER["REMOTE_ADDR"]){
		$ip = $_SERVER["REMOTE_ADDR"];
	}else if (@getenv("HTTP_X_FORWARDED_FOR")){
		$ip = getenv("HTTP_X_FORWARDED_FOR");
	}else if (@getenv("HTTP_CLIENT_IP")){
		$ip = getenv("HTTP_CLIENT_IP");
	}else if (@getenv("REMOTE_ADDR")){
		$ip = getenv("REMOTE_ADDR");
	}else{
		$ip = "Unknown";
	}
	return $ip;
}
if ($_SERVER['HTTP_USER_AGENT'] != "br34k1n-Web-Broswer"){
	die("You must use [br34k1n-Web-Broswer] to view this page! Other web broswer will be denied!");
}
if (getIP() != "127.0.0.1"){
	die("System Detect a hacker Presents This page is only for local client!");
}
if ($_SERVER['REMOTE_PORT'] != 23333){
	die("Only port 23333 is allowed!");
}else
	echo $flag;
}
?>
