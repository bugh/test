<?php

$cip=$_POST['flag'];
$txt="W3b_1s_E4sy_N4h";
if($cip == $txt)
{
  echo "<h1 align='center'>FL4G{Ceas3r_Know_It}</h1>";
}
else {
  echo "<h1 align='center'>Failed</h1>";
}

 ?>
