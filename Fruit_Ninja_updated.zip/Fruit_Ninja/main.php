<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Fruit Ninja | CTF </title>
  </head>
  <body>
<center>
<h4>Sorry Guys, I'm Blank</h4>
<img src=""></center>
  </body>
</html>
