<!DOCTYPE html>

<?php
error_reporting(0);
$file = $_GET["file"];
if(!empty($file)){
  if(!preg_match("/^\s*\/|^\s*file:\/\/|^.*?\.\..*?$/", $file)){
    echo "<pre>";
    echo file_get_contents($file);
    echo "</pre>";
  } else {
    echo "Don't even think about it!";
  }
}
?>

<html>
  <head>
    <meta charset="utf-8">
    <title> Look_Closer | CTF </title>
    <meta name="description" content="" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="generator" content="Codeply">
    <link rel="stylesheet" href="./css/bootstrap.min.css" />
    <link rel="stylesheet" href="./css/animate.min.css" />
    <link rel="stylesheet" href="./css/ionicons.min.css" />
    <link rel="stylesheet" href="./css/styles.css" />
  </head>
  <body>
    <nav id="topNav" class="navbar navbar-default navbar-fixed-top">
        <div class="container-fluid">
            <div class="navbar-collapse collapse" id="bs-navbar">
                <ul class="nav navbar-nav">
                    <li>
                        <a class="page-scroll" href="#">Init Crew Community</a>
                    </li>                    
                </ul>
            </div>
        </div>
    </nav>
    <header id="first">
        <div class="header-content">
            <div class="inner">
                <h1 class="cursive">Look Closer</h1>
                <span>Look for the file named "vault". It is <b>not</b> stored within /var/www/html/</span>
                <hr>
                <a href="?file=serverfile.html" class="btn btn-primary btn-xl page-scroll"><b>Internal 1</b></a> &nbsp; <a href="?file=serverlog.html" class="btn btn-primary btn-xl page-scroll"><b>Internal 2</b></a>
            </div>
        </div>
    </header>
    <footer id="footer">
            <span class="pull-right text-muted small" >@ InitCrew 2020</span>
    </footer>
    <div id="galleryModal" class="modal fade" tabindex="-1" role="dialog" aria-hidden="true">
        <div class="modal-dialog modal-lg">
        <div class="modal-content">
        	<div class="modal-body">
        		<img src="" id="galleryImage" class="img-responsive" />
        		    <br/>
        	</div>
        </div>
        </div>
    </div>
    <!--scripts loaded here -->
    <script src="./js/jquery.min.js"></script>
    <script src="./js/bootstrap.min.js"></script>
    <script src="./js/jquery.easing.min.js"></script>
    <script src="./js/wow.js"></script>
    <script src="./js/scripts.js"></script>
  </body>
</html>
